from datetime import datetime
import json
import re



  
def open_json(file):
  # Opening JSON file
  f = open(file)
  d = json.load(f)
  return d

class bcolors:
  
  HEADER = '\033[95m'
  OKBLUE = '\033[94m'
  OKCYAN = '\033[96m'
  OKGREEN = '\033[92m'
  WARNING = '\033[93m'
  FAIL = '\033[91m'
  ENDC = '\033[0m'
  BOLD = '\033[1m'
  UNDERLINE = '\033[4m'

def get_param_dic(key,value,list):
  params=[]
  for i in list:
    try: 
      if i['dialog_node']==value: ## encuentra el parent objetivo  
        params.append(i[key])
    except: None
      
  return params

### Llamar JSON
data = open_json('dialognodes.json')
list_json=data['dialog_nodes']
message = open_json('backtoconv.json')


def p(a):
  
  print(a)

def pcolor(list):
  i=1
  for l in list:
    if i==1:
      print(l)
    if i==0:
      print(Fore.GREEN,l)  
    
    if i == 1: i=0
    if i == 0: i=1 
  print(Style.RESET_ALL)
  list1=[1,2,3,4,5]
  pcolor(list1)
  
def open_json(file):
  # Opening JSON file
  f = open(file)
  d = json.load(f)
  return d

def unique(list1):
  
    # initialize a null list
    unique_list = []
  
    # traverse for all elements
    for x in list1:
        # check if exists in unique_list or not
        if x not in unique_list:
            unique_list.append(x)
        else:
          continue
    # print list
    
    return(unique_list)

def save_json(dic):
  
  with open("sample.json", "w") as outfile:
    json.dump(dic, outfile)




#Convertir condición a formato python y hacer que las variables llamen al json context[""]
#Convertir condición a formato python y hacer que las variables llamen al json context[""]
#Convertir condición a formato python y hacer que las variables llamen al json context[""]

def find_transf_date(str):##### buscar fechas en context
  strtodate = datetime.now().date()
  prog = re.compile(r'([\d]{4})(-)([\d]{2})(-)([\d]{2})')
  found=prog.search(str)
  if True:
    try:
      strtodate= datetime.strptime(found.group(0), '%Y-%m-%d').date()
      
      return strtodate
    except: None
  else: 
    return str
    
context_values2=""

def transf_var_ctx(var,json_name): #### Transformación de variavles $ a py
  
  prog = re.compile(r'([$])([\w_]+)')
  found=prog.match(var)
  
  if found:
    py_var=json_name+"""['context'].get('"""+found[2]+"""')"""
    # str = "global context_values2; context_values2 = "+py_var
    # exec(str)
    
    
    
    # print(isinstance(find_transf_date(context_values2),datetime.date))
    
    # if isinstance(find_transf_date(context_values2),datetime.date) :
    #   p("^")
    #   json_name['context'][found[2]]=(find_transf_date(context_values2))
    #   print("*************",json_name['context'][found[2]])
    return py_var
  else: var



def get_all_var_ctx(condition): ##### Obtener listado de variables de contexto
  
  list_var_ctx=[]
  condition = condition.replace("&&","")
  condition = condition.replace("||","")
  list_var=re.split('=|!|<|>| ',condition)
  
  for r in list_var: ##s
    
    if r and r != "" and r != " ": 
      prog = re.compile(r'([$])([\w_]+)')
      found=prog.findall(r)
      
      try:
        for f in found: 
          var ="".join(f)
          list_var_ctx.append(var)
      except: None
      
  return unique(list_var_ctx)    



def change_all_vars_ctx(condition):
  
  try:
    
    for c in get_all_var_ctx(condition):
      
      transf_var_ctx(c,"message")
      condition=condition.replace(c,transf_var_ctx(c,"message"))
      
  except: None
  
  return condition



def get_plus_days (condition,json_name):##### Reemplazar función plusDays

  
  prog = re.compile(r'(\b.plusDays\b)([(])([\w$]+)([)])')
  found=prog.findall(condition)
  try:
    for f in found: 
      plus_day_old= "".join(f)
      plus_day_new= """ + timedelta(days= """ + f[2] +""" )"""
      condition=condition.replace(plus_day_old,plus_day_new)
  except: None
  return condition



def get_matches (condition,json_name):##### Reemplazar función .matches

  prog = re.compile(r"([\w_@$-.]+)(\b.matches\b)([(])([\w., ']+)([)])")
  found=prog.findall(condition)
  try:
    for f in found: 
      matches_old = "".join(f)
      matches_new = """re.search("""+f[3]+","+f[0]+")"
      condition=condition.replace(matches_old,matches_new)
  except: None
  return condition



def get_size (condition,json_name):##### Reemplazar función size()

  
  prog = re.compile(r'([\w_@$-]+)(\b.size\b)([()]+)')
  found=prog.findall(condition)
  try:
    for f in found: 
      size_old= "".join(f)
      size_new= """ len(""" + f[0] +""")"""
      condition=condition.replace(size_old,size_new)
  except: None
  return condition



def get_toint (condition,json_name):##### Reemplazar función toint()
  
  prog = re.compile(r'([\w_@$-.]+)(\b.toInt\b)([()]+)')
  found=prog.findall(condition)
  
  try:
    for f in found: 
      size_old= "".join(f)
      size_new= """ int(""" + f[0] +""")"""
      condition=condition.replace(size_old,size_new)
  except: None
  return condition



def get_func_transf(condition,json_name):   ##### transformar funciones de condicióm a formato python
  
  condition = condition.replace('today()',"datetime.today()")
  condition = condition.replace('toInt()'," and ")
  condition = condition.replace("input.text",(json_name+"['input']['text']"))
  return condition



def get_basic_transf(condition):  ##### transformar operadores básicos de condición a formato python
  
  condition = condition.replace('\"',"'")
  condition = condition.replace("&&"," and ")
  condition = condition.replace("||"," or ")
  condition = condition.replace("true"," True ")
  condition = condition.replace("false"," False ")
  condition = condition.replace("null"," None ")
  
  return condition





########### PRUEBAS GENERALES#########

# i=0
json_name="message"
# for l in list_json: 
#   try:  
#     condition = get_param_dic('conditions',l['dialog_node'],list_json)
#     for c in condition:
      
#       d=c
#       try: c = get_plus_days(c,json_name)
#       except: None
#       try: c = get_matches(c,json_name)
#       except: None
#       try: c = get_size(c,json_name)
#       except: None
#       try: c = get_toint(c,json_name)
#       except: None
#       try: c = get_func_transf(c,json_name)
#       except: None
#       try: c = get_basic_transf(c)
#       except: None
#       try: c = change_all_vars_ctx(c)
#       except: None     
#       # print(i,d,"|||||",c)  
#       i=i+1  
#   except: None


def get_conditions(dialog_node):

  try: 
    condition = get_param_dic('conditions',dialog_node,list_json)
    
    for c in condition:
      
      try: c = get_plus_days(c,json_name)
      except: None
      try: c = get_matches(c,json_name)
      except: None
      try: c = get_size(c,json_name)
      except: None
      try: c = get_toint(c,json_name)
      except: None
      try: c = get_func_transf(c,json_name)
      except: None
      try: c = get_basic_transf(c)
      except: None
      try: c = change_all_vars_ctx(c)
      except: None     
      return c
  except: None



# print(get_conditions("response_85_1644514496586"))





# datetime1= find_transf_date(message['context'].get('fecha_cuarta_dosis_a_evaluar'))


# if  datetime1    <=   datetime.today(): p("BKN1")

# string_1="if message['context'].get('fecha_cuarta_dosis_a_evaluar') <= datetime.today()  and  message['context'].get('fecha_bd_segunda_dosis')  and  message['context'].get('fecha_cuarta_dosis_a_evaluar') < message['context'].get('fecha_bd_tercera_dosis') + timedelta(days= message['context'].get('umbral_segunda_dosis') ): print(1)"

# "2022-01-01"
# exec(string_1)


















############# PRUEBAS #########

# s="$fecha_tercera_dosis_a_evaluar < $fecha_bd_segunda_dosis.plusDays($umbral_segunda_dosis) or $fecha_tercera_dosis_a_evaluar < $fecha_bd_segunda_dosis.plusDays($umbral_tercera_dosis)"

# s=get_plus_days(s,"message")
# s=get_basic_transf(s,"message")
# s=change_all_vars(s)

# sintaxis= "if "+s + """: p('bkn')"""
# print(sintaxis)

# p(get_basic_transf(get_matches("input.text.matches('Lo desconozco o no tengo seguridad') || input.text.matches('3')","message"),"message"))


condition="$preguntar_cuarta_dosis || ($posible_fecha_cuarta_dosis != null && $posible_fecha_cuarta_dosis <= today() && $tipo_vacuna_segunda_dosis == '1' && $tipo_vacuna_tercera_dosis == '1' ) || ($posible_fecha_cuarta_dosis != null && $posible_fecha_cuarta_dosis <= today() && $tipo_vacuna_segunda_dosis == '2' && $tipo_vacuna_tercera_dosis == '2' ) ||($posible_fecha_cuarta_dosis != null && $posible_fecha_cuarta_dosis <= today() && $tipo_vacuna_segunda_dosis == '2' && $tipo_vacuna_tercera_dosis == '3' ) ||($posible_fecha_cuarta_dosis != null && $posible_fecha_cuarta_dosis <= today() && $tipo_vacuna_segunda_dosis == '3' && $tipo_vacuna_tercera_dosis == '3' ) ||($posible_fecha_cuarta_dosis != null && $posible_fecha_cuarta_dosis <= today() && $tipo_vacuna_segunda_dosis == '6' && $tipo_vacuna_tercera_dosis == '6' ) ||($posible_fecha_tercera_dosis != null && $posible_fecha_tercera_dosis <= today() && $tipo_vacuna_segunda_dosis == '4' ) ||($posible_fecha_tercera_dosis != null && $posible_fecha_tercera_dosis <= today() && $tipo_vacuna_segunda_dosis == '5' ) || $prueba=='prueba'|| input.text ='juan' || $fecha_tercera_dosis_a_evaluar < $fecha_bd_segunda_dosis.plusDays($umbral_segunda_dosis)"

# p(get_basic_transf(condition,"hola"))

# for g in get_var_ctx(condition):p(g)

# list_func=['today(','plusDays(','size(','toInt(','matches(']
# list_func=['matches(']
# for l in list_json: 
#   try: 
#     param = get_param_dic('conditions',l['dialog_node'],list_json)
#     for func in list_func:
#       if func in param[0]:
#         p(param[0])
        
#   except: None
        





#     # if "&&" in l['conditions'] and "||" in l['conditions']:
# for l in list_json:
#   try: 
#       l_split = l['conditions'].replace("&&","")
#       l_split = l_split.replace("||","")
      
#       list_sep=re.split('=|!|<|>| ',l_split)
      

#       # for r in list_sep: ##s
#       #   if r and r != "" and r != " ": 
#       #     prog = re.compile(r'([$])([\w_]+)')
#       #     found=prog.findall(r)
#       #     try:
#       #       for f in found: 
              
#       #         r ="".join(f)
#       #         list_context.append(r)
#       #     except: None



#       for r in list_sep: ##s
        
#         if r and r != "" and r != " ": 
#           prog = re.compile(r'([.])([w_]+)')
#           found = prog.findall(r)
#           try:
            
#             for f in found: 
#               print(f)
#               r = "".join(f)
#               list_context.append(r)
          
#           except: None



#   except: None


# list_context =(unique(list_context))

# for lc in list_context:
#   if lc != "" and lc != " ":
#     print(lc)  
  


# mycode = "if correo_paciente!=None: p(1)"
# exec(mycode)



# list_context=unique(list_context)

# # ### Calcular lista completa de dependencias para todos los nodos
# lista_final=[]

# for l in list_json:
#   try: 
#     # print(get_dependence(l['dialog_node'],list_json),"\n")
    
#     lista_final.append(get_dependence(l['dialog_node'],list_json))
#   except: None
# # print(len(lista_final))
# # print(lista_final)
# # for x in range(len(lista_final)):
# #   print(lista_final[x])    

